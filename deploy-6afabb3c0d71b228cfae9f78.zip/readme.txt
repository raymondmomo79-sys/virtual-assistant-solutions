RAYMOND MOMO PORTFOLIO WEBSITE

PAGGAMIT SA WEBSITE
1. I-extract ang ZIP file o ablihi ang folder nga raymond-momo-portfolio.
2. Sa PC, i-double-click ang index.html aron ablihan sa web browser.
3. Ayaw ibulag ang index.html gikan sa assets folder; gikinahanglan kini sa mga hulagway.
4. Ang mga hulagway gi-convert ngadto sa WebP aron mas gamay ang file ug mas paspas mo-load.
5. Aron maablihan sa cellphone pinaagi sa web link, i-upload ang tibuok folder sa imong website hosting ug siguroa nga magpabilin ang assets folder tupad sa index.html.

ANG INQUIRY FORM
Isulat ang imong ngalan, email, ug mensahe, dayon pilia ang Send. Moabli ang imong email app nga naka-address na kang Raymond. Susiha ug ipadala ang mensahe gikan didto.

CONTACT
Email: raymondmomo79@gmail.com
LinkedIn: https://www.linkedin.com/in/raymond-momo-virtualassistant/
Facebook: https://www.facebook.com/profile.php?id=61596173051215
Wala giapil ang booking link kay wala pay booking URL sa portfolio brief.

SULOD SA PACKAGE
index.html  - Portfolio website ug responsive styling
assets/     - WebP logo, profile photo, banner, ug portfolio images

Ang page adunay smooth transitions ug subtle click sound effects.


Human pilion ang Send, mo-play ang thank-you video isip gamay nga PiP card sa kilid. Pilia ang Ipadayon ug ipadala ang inquiry aron maablihan ang email draft.


